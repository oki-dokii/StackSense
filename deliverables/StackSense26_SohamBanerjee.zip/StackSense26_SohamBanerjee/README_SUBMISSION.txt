StackSense 0.9.0 - Soham Banerjee, IIIT-Bangalore

Extract source/source.zip, then run npm ci, npm run build, npm start.
Open http://127.0.0.1:3000. Requires Node 22.17+ within 22, or Node 24.

LLM-off: append --no-llm to CLI commands. No runtime LLM is used.
Public results: one ok and five ok_with_warnings, all with selected stacks.
P2/P4/P5/P6 contain explicit critical provisional conditions. A selected stack
is not certification or verification of an unresolved residency/contract scope.
Headline costs cover infrastructure; payment/SMS activity scenarios are additional.

The archive includes current source, six actual outputs, the project report,
research/credits and a SHA-256 manifest. Follow the organiser's required Drive
folder/link submission format and do not modify the submitted folder after
the stated deadline.
