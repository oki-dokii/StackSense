StackSense 0.5.0 - Soham Banerjee, IIIT-Bangalore

Extract source/source.zip, then run npm ci, npm run build, npm start.
Open http://127.0.0.1:3000. Node 22.17+ within 22, or Node 24.

Public results: one ok, one ok_with_warnings, four infeasible due reviewed
external-residency/provider evidence gaps. No-plan 0-0 costs are not estimates.
The report documents actual tests, assumptions, references and AI assistance.

Owner actions remain: review and own the AI-assisted design/research; verify
Drive sharing/access, submit the folder link on Unstop, and freeze the folder
after the stated deadline. This local package has not been submitted online.
